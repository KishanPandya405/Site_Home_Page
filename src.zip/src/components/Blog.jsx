import React, { useEffect, useState } from 'react';

import axios from 'axios';
import '../Styles/Blog.css'

const Blog = () => {

  const [blogs, setBlogs] = useState([]);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Fetch blog data when the component mounts
    const fetchBlogs = async () => {
      try {
        setLoading(true);
        const response = await axios.get('https://api.postman.com/collections/21192250-a50e1277-1ba5-4391-8937-80b388c049d9?access_key=PMAT-01HEAST02Z383GF562ABYFR5RX');
        setBlogs(response.data); // assuming the API returns an array of blog objects
        setLoading(false);
      } catch (err) {
        setError('Failed to load blogs. Please try again later.');
        setLoading(false);
      }
    };

    fetchBlogs();
  }, []);
  return (
    
      <div className="section">
        <div className="boxes">
          <h3>Testimonial</h3>
          <div className="box1">
            <img src="Image.png" alt="" />
            <h5>Josh brollins</h5>
            <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua</p>
          </div>
          <div id='box2' className="box1">
          <img src="Image.png" alt="" />
            <h5>Josh brollins</h5>
            <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua</p>
          </div>
        </div>

        <div className="blogs">
      <div className="blog-header">
        <h3>Blogs</h3>
        <p>View All</p>
      </div>

      {loading && <p>Loading...</p>}
      {error && <p style={{ color: 'red' }}>{error}</p>}

      <div className="blog-list">
        {blogs.length > 0 ? (
          blogs.map((blog, index) => (
            <div className="blog" key={index}>
              <img src={blog.image || 'default-image-url'} alt={blog.title} />
              <h5>{blog.title}</h5>
              <p>{blog.description}</p>
            </div>
          ))
        ) : (
          <p>No blogs available at the moment.</p>
        )}
      </div>
    </div>
    </div>
  );
};

export default Blog;
