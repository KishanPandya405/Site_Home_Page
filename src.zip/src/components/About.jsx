import React from 'react'
import '../Styles/About.css'

const About = () => {
  return (
    <div className='about'>
        <img src="about1.png" alt="" />
        
        <div className='sub-about'>
            <h3>About us</h3>
            <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor Lorem ipsum dolor sit amet consetetur sadipscing elitr</p>
            <button></button>
            <img id='image2' src="about2.png" alt="" />
        </div>
        
    </div>
  )
}

export default About;